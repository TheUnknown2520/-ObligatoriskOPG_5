﻿using ObligatoriskOPG;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading.Tasks;


namespace ObligatoriskOPG_5
{
    class ServerWorker
    {
        public ServerWorker()
        {

        }

        public static List<FootballPlayer> Players = new List<FootballPlayer>()
        {
            new FootballPlayer(1, "Christopher", 200, 1)
        };

        [Obsolete]
        public void Start()
        {
            TcpListener listener = new TcpListener(2121);
            listener.Start();

            while(true)
            {
                TcpClient socket = listener.AcceptTcpClient();
                Task.Run(
                    () =>
                    {
                        TcpClient tmpSocket = socket;
                        DoClient(tmpSocket);
                    });
            }
        }

        private void DoClient(TcpClient socket)
        {
            using(StreamReader r = new StreamReader(socket.GetStream()))
            using(StreamWriter w = new StreamWriter(socket.GetStream()))
            {
                string str1 = r.ReadLine();
                string str2 = r.ReadLine();

                switch(str1)
                {
                    case "hent alle": string json = JsonSerializer.Serialize(Players);
                        w.WriteLine(json);
                        w.Flush();
                        break;

                    case "hent": int id = Convert.ToInt32(str2);
                        FootballPlayer player = Players.Find(P => P.Id == id);
                        string json2 = JsonSerializer.Serialize(player);
                        w.WriteLine(json2);
                        w.Flush();
                        break;

                    case "gem": FootballPlayer footBallPlayer = JsonSerializer.Deserialize<FootballPlayer>(str2);
                        Players.Add(footBallPlayer);
                        break;
                }
            }
            
        }
    }
}
